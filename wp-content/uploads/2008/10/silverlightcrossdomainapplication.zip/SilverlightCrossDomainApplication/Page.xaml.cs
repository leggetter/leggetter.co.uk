﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Text;
using System.Diagnostics;

namespace SilverlightCrossDomainApplication
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
        }

        private void RequestButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri("http://www.leggetter.co.uk/"));
                request.BeginGetResponse(HandleResponse, request);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        private void HandleResponse(IAsyncResult result)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)result.AsyncState;
                HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(result);

                StringBuilder readText = new StringBuilder();
                using (Stream responseStream = response.GetResponseStream())
                {
                    byte[] buffer = new byte[1024];
                    int read = responseStream.Read(buffer, 0, buffer.Length);
                    while (read > 0)
                    {
                        readText.Append(Encoding.UTF8.GetString(buffer, 0, read));
                        read = responseStream.Read(buffer, 0, buffer.Length);
                    }
                }
                // TODO: This is gonna barf as we need to be on the UI Thread
                Dispatcher.BeginInvoke(delegate()
                {
                    ResponseText.Text = readText.ToString();
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

    }
}
